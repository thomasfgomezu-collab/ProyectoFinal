public enum EstadoSala {
    DISPONIBLE,
    DESHABILITADA
}
